class Assignment < ApplicationRecord
end
