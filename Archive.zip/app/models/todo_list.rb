class TodoList < ApplicationRecord
end
